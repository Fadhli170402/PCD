import sys
import cv2
import numpy as np
from PyQt5 import QtCore, QtWidgets
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
from PyQt5.uic import loadUi
from cv2 import setWindowTitle
from  PyQt5.QtGui import QImage, QPixmap
from PyQt5.QtWidgets import QApplication, QMainWindow
from PyQt5 import QtCore, QtGui, QtWidgets
import math
from matplotlib import  pyplot as plt

class ShowImage(QMainWindow):
    def __init__(self):
        super(ShowImage, self).__init__()
        self.konstantaBrightness = 0
        self.konstantaKontras = 0
        self.brightness = 0
        self.nkontras = 0
        self.gambar = None
        self.Image = None
        loadUi('gui1.ui', self)
        self.pushButton.clicked.connect(self.fungsi)
        self.proses_citra.clicked.connect(self.grayscale)
        self.actionGrayscale.triggered.connect(self.grayscale)
        self.actionOperasi_Pencerahan.triggered.connect(self.pencerahan)
        self.actionSimpel_Contras.triggered.connect(self.kontras)
        self.actionPeregangan_Contras.triggered.connect(self.peregangancontras)
        self.actionNegativ_Image.triggered.connect(self.negativ)
        self.actionBiner_Image.triggered.connect(self.binerimage)
        self.actionOpen.triggered.connect(self.openClicked)
        self.actionSave.triggered.connect(self.save)
        self.brightnessSlider.valueChanged.connect(self.brightnesslider)
        self.buttonbrightness.clicked.connect(self.nilaibrightness)
        self.kontrasSlider.valueChanged.connect(self.kontrasslider)
        self.buttonkontras.clicked.connect(self.nilaikontras)
        self.actionHistogram_Graysacle.triggered.connect(self.grayscalehistogram)
        self.actionHistogram_RGB.triggered.connect(self.rgbhistogram)
        self.actionHistogram_Equalization.triggered.connect(self.equalhistogram)
        #operasi geometri
        self.actionTranslasi.triggered.connect(self.translasi)
        self.action_45_Derajat.triggered.connect(self.rotasiminus45)
        self.action90derajat.triggered.connect(self.rotasi90derajat)
        self.action_90_Derajat.triggered.connect(self.rotasiminus90)
        self.action45_Derajat.triggered.connect(self.rotasi45derajat)
        self.action45_Derajat.triggered.connect(self.rotasi45derajat)
        self.action180_Derajat.triggered.connect(self.rotasi180)
        self.action2x.triggered.connect(self.zoomIn2x)
        self.action3_X.triggered.connect(self.ZoomIn3x)
        self.action4_X.triggered.connect(self.ZoomIN4x)
        self.action1_2.triggered.connect(self.ZoomOutsetengah)
        self.action1_4.triggered.connect(self.ZoomOutsatupere4)
        self.action3_4.triggered.connect(self.ZoomOut3per4)
        self.actionSkewed.triggered.connect(self.skewed)
        self.actionCrop.triggered.connect(self.crop)
        self.actionTranspose.triggered.connect(self.transpose)
        #operasi aritmatika
        self.actionTambah_dan_Kurang.triggered.connect(self.aritmatikatambahkurang)
        self.actionKali_dan_Bagi.triggered.connect(self.aritmatikakalibagi)
        #Operasi Bolean
        self.actionOperasi_AND.triggered.connect(self.operasiAND)
        self.actionOperasi_OR.triggered.connect(self.operasiOR)
        #operasi sapsial
        self.actionKonvolusi_2D.triggered.connect(self.konvolusi2D)

    def openClicked(self):
        flname, filter = QFileDialog.getOpenFileName(self, 'Open File', 'C:\\User\\', "Image Files(*.jpg)")
        if flname:
            self.loadImage(flname)
            print('Nilai Piksel Awal: ', self.Image[0:1, 0:1])
        else:
            print('Invalid Image')

    def save(self):
        flname, filter = QFileDialog.getSaveFileName(self, 'save file', 'C:\\', "Images Files(*.jpg)")
        if flname:
            cv2.imwrite(flname, self.Image)
        else:
            print('Saved')

    def loadImage(self, flname):
        self.Image = cv2.imread(flname)
        self.gambar = str(flname)
        self.displayImage(1)
        self.Image2 = self.Image

    def brightnesslider(self):
        self.konstantaBrightness = str(self.brightnessSlider.value())
        self.labelbrightness.setText(self.konstantaBrightness)

    def nilaibrightness(self):
        self.pencerahan()

    def kontrasslider(self):
        self.konstantaKontras = str(self.kontrasSlider.value())
        self.labelkontras.setText(self.konstantaKontras)

    def nilaikontras(self):
        self.kontras()

    def fungsi(self):
        self.Image = cv2.imread('ginjal.jpg')
        self.displayImage()

    def grayscale(self):
        H, W = self.Image.shape[:2]
        gray = np.zeros((H, W), np.uint8)
        for i in range(H):
            for j in range(W):
                gray[i, j] = np.clip(0.299 * self.Image[i,j, 0] +
                                     0.587 * self.Image[i,j, 1] +
                                     0.114 * self.Image[i,j, 2], 0, 255)
        self.Image = gray
        self.displayImage(2)
        print('Nilai Piksel Operasi Grayscale: ', self.Image[0:1, 0:1])

    def pencerahan(self):
        # Agar menghindari eror ketika melewati grayscaling citra
        try:
            self.Image = cv2.cvtColor(self.Image, cv2.COLOR_BGR2GRAY)
        except:
            pass

        H, W = self.Image.shape[:2]
        self.brightness = int(self.konstantaBrightness)
        for i in range(H):
            for j in range(W):
                a = self.Image.item(i, j)
                b = np.clip(a + self.brightness, 0, 255)

                self.Image.itemset((i, j), b)
        self.displayImage(2)
        print('Nilai Piksel Operasi Pencerahan: ', self.Image[0:1, 0:1])
    def kontras(self):
        try:
            self.Image = cv2.cvtColor(self.Image, cv2.COLOR_BGR2GRAY)
        except:
            pass

        H, W = self.Image.shape[:2]
        nkontras = int(self.konstantaKontras) + 0.3
        for i in range(H):
            for j in range(W):
                a = self.Image.item(i, j)
                b = np.clip(a * nkontras, 0, 255)

                self.Image.itemset((i, j), b)
        self.displayImage(2)
        print('Nilai Piksel Operasi Kontras: ', self.Image[0:1, 0:1])

    def peregangancontras(self):
        try:
            self.Image = cv2.cvtColor(self.Image, cv2.COLOR_BGR2GRAY)
        except:
            pass

        H, W = self.Image.shape[:2]
        minV = np.min(self.Image)
        maxV = np.max(self.Image)
        for i in range(H):
            for j in range(W):
                a = self.Image.item(i, j)
                b = float(a - minV) / (maxV - minV) * 255

                self.Image.itemset((i, j), b)
        self.displayImage(2)
        print('Nilai Piksel Operasi Peregangan Kontras: ', self.Image[0:1, 0:1])

    def negativ(self):
        try:
            self.Image = cv2.cvtColor(self.Image, cv2.COLOR_BGR2GRAY)
        except:
            pass

        H, W = self.Image.shape[:2]
        for i in range(H):
            for j in range(W):
                a = self.Image.item(i,j)
                b = math.ceil(255 - a)

                self.Image.itemset((i,j), b)
            self.displayImage(2)
        print('Nilai Piksel Operasi Negative: ', self.Image[0:1, 0:1])

    def binerimage(self):
        H,W = self.Image.shape[:2]
        treshold = 50

        for i in range(H):
            for j in range(W):
                a = self.Image.item(i,j)
                if a == treshold:
                    b = 0
                elif a < treshold:
                    b = 1
                elif a > treshold:
                    b = 255
                self.Image.itemset((i,j), b)
        self.displayImage(2)
        print('Nilai Piksel Operasi Biner Image: ', self.Image[0:1, 0:1])

    def equalhistogram(self):
        hist, bins = np.histogram(self.Image.flatten(), 256, [0, 256])
        cdf = hist.cumsum()
        cdf_normalized = cdf * hist.max() / cdf.max()
        cdf_m = np.ma.masked_equal(cdf, 0)
        cdf_m = (cdf_m - cdf_m.min()) * 255 / (cdf_m.max() - cdf_m.min())
        cdf = np.ma.filled(cdf_m, 0).astype("uint8")
        self.Image = cdf[self.Image]
        self.displayImage(2)

        plt.plot(cdf_normalized, color="b")
        plt.hist(self.Image.flatten(), 256, [0, 256], color="r")
        plt.xlim([0, 256])
        plt.legend(("cdf", "histogram"), loc="upper left")
        plt.show()




    def rgbhistogram(self):
        color = ("b","g","r")
        for i, col in enumerate(color):
            histo = cv2.calcHist([self.Image], [i], None, [256], [0, 256])
            plt.plot(histo, color=col)
            plt.xlim([0,256])
        self.displayImage(2)
        plt.show()

    def grayscalehistogram(self):
        H, W = self.Image.shape[:2]
        gray = np.zeros((H, W), np.uint8)
        for i in range(H):
            for j in range(W):
                gray[i, j] = np.clip(0.299 * self.Image[i, j, 0] +
                                     0.587 * self.Image[i, j, 1] +
                                     0.114 * self.Image[i, j, 2], 0, 255)
        self.Image = gray
        self.displayImage(2)
        print('Nilai Piksel Operasi Grayscale: ', self.Image[0:1, 0:1])
        plt.hist(self.Image.ravel(), 255,[0,255])
        plt.show()

    def translasi(self):
        h,w = self.Image.shape[:2]
        quarter_h, quarter_w = h/5, w/10
        T = np.float32([[1, 0, quarter_w],[0, 1, quarter_h]])
        img = cv2.warpAffine(self.Image, T,( w,h))
        self.Image = img
        self.displayImage(2)

    def rotasi90derajat(self):
        self.rotasi(90)

    def rotasiminus45(self):
        self.rotasi(-45)

    def rotasi45derajat(self):
        self.rotasi(45)

    def rotasiminus90(self):
        self.rotasi(-90)

    def rotasi180(self):
        self.rotasi(180)

    def rotasi(self, derajat):
        h, w = self.Image.shape[:2]
        rotationMatrix = cv2.getRotationMatrix2D((w / 2, h / 2), derajat, 0.7)
        cos = np.abs(rotationMatrix[0, 0])
        sin = np.abs(rotationMatrix[0, 1])
        nW =int((h *sin) + (w * cos))
        nH = int((h * cos) + (w * sin))

        rotationMatrix[0, 2] += (nW / 2) - w /2
        rotationMatrix[1, 2] += (nH / 2) - h /2

        rot_Image = cv2.warpAffine(self.Image, rotationMatrix, (h,w))
        self.Image = rot_Image
        self.displayImage(2)


    def zoomIn2x(self):
        skala = 2
        resize_Image = cv2.resize(self.Image, None, fx=skala, fy=skala, interpolation=cv2.INTER_CUBIC)
        cv2.imshow('Original Image',self.Image)
        cv2.imshow('Zoom in 2x',resize_Image)
        cv2.waitKey()

    def ZoomIn3x(self):
        skala = 3
        resize_Image = cv2.resize(self.Image, None ,fx=skala, fy=skala, interpolation=cv2.INTER_CUBIC)
        cv2.imshow('Original Image', self.Image)
        cv2.imshow('Zoom In 3X', resize_Image)
        cv2.waitKey()

    def ZoomIN4x(self):
        skala = 4
        resize_Image = cv2.resize(self.Image, None, fx=skala, fy=skala, interpolation=cv2.INTER_CUBIC)
        cv2.imshow('Original Image', self.Image)
        cv2.imshow('Zoom In 4x ', resize_Image)
        cv2.waitKey()

    def ZoomOutsetengah(self):
        skala = 0.5
        resize_Image = cv2.resize(self.Image, None, fx=skala, fy=skala, interpolation=cv2.INTER_CUBIC)
        cv2.imshow('Original Image', self.Image)
        cv2.imshow('Zoom Out 1/2 ', resize_Image)
        cv2.waitKey()

    def ZoomOutsatupere4(self):
        skala = 0.25
        resize_Image = cv2.resize(self.Image, None, fx=skala, fy=skala, interpolation=cv2.INTER_CUBIC)
        cv2.imshow('Original Image ',self.Image)
        cv2.imshow('Zoom Out 1/4 ',resize_Image)
        cv2.waitKey()

    def ZoomOut3per4(self):
        skala = 0.75
        resize_Image = cv2.resize(self.Image, None, fx=skala, fy=skala, interpolation=cv2.INTER_CUBIC)
        cv2.imshow('Original Image ',self.Image)
        cv2.imshow('Zoom Out 3/4',resize_Image)
        cv2.waitKey()

    def skewed(self):
        resize_Image = cv2.resize(self.Image,(600, 500), interpolation=cv2.INTER_AREA)
        cv2.imshow('Original', self.Image)
        cv2.imshow('Skewed',resize_Image)
        cv2.waitKey(0)

    def transpose(self):
        h,w = self.Image.shape[:2]
        transpose_img = cv2.transpose(self.Image)
        self.Image = transpose_img
        self.displayImage(2)

    def crop(self):
        startRow, startCol = 0 , 0
        endRow , endCol = 537, 670
        img= self.Image
        cropimg = img[startRow:endRow, startCol:endCol]
        cv2.imshow('Original', self.Image)
        cv2.imshow('crop',cropimg)
        cv2.waitKey()


    def aritmatikatambahkurang(self):
        img1 = cv2.imread('futsal1.jpg',0)
        img2 = cv2.imread('futsal2.jpg', 0)
        tambah_img = img1 + img2
        kurang_img = img1 - img2

        cv2.imshow('Image Tambah', tambah_img)
        cv2.imshow('Image Kurang', kurang_img)

        print('Nilai Piksel Operasi Tambah: ', tambah_img)
        print('Nilai Piksel Operasi Kurang: ',  kurang_img)
        cv2.waitKey(0)

    def aritmatikakalibagi(self):
        img1 = cv2.imread('futsal1.jpg', 0)
        img2 = cv2.imread('futsal2.jpg', 0)
        kali_img = img1 * img2
        bagi_img = img1 / img2

        cv2.imshow('Image Kali ', kali_img)
        cv2.imshow('Image Bagi ', bagi_img)
        print('Nilai Piksel Operasi kali: ', kali_img)
        print('Nilai Piksel Operasi Bagi: ', bagi_img)
        cv2.waitKey(0)

    def operasiAND(self):
        image1 = cv2.imread('futsal1.jpg', 1)
        image2= cv2.imread('futsal2.jpg', 1)
        image1 = cv2.cvtColor(image1, cv2.COLOR_BGR2RGB)
        image2 = cv2.cvtColor(image2, cv2.COLOR_BGR2RGB)
        operasi = cv2.bitwise_and(image1,image2)
        cv2.imshow('image 1 Oringinal', image1)
        cv2.imshow('image 2 Oringinal', image2)
        cv2.imshow('Image Operasi AND ', operasi)
        cv2.waitKey()

    def operasiOR(self):
        image1 = cv2.imread('futsal1.jpg', 1)
        image2= cv2.imread('futsal2.jpg', 1)
        image1 = cv2.cvtColor(image1, cv2.COLOR_BGR2RGB)
        image2 = cv2.cvtColor(image2, cv2.COLOR_BGR2RGB)
        operasi = cv2.bitwise_or(image1,image2)
        cv2.imshow('image 1 Oringinal', image1)
        cv2.imshow('image 2 Oringinal', image2)
        cv2.imshow('Image Operasi AND ', operasi)
        cv2.waitKey()

    def filtering(self, X, F):
        X_height = X.shape[0]
        X_width = X.shape[1]
        F_height = F.shape[0]
        F_width = F.shape[1]
        H = (F_height) // 2
        W = (F_width) // 2
        out = np.zeros((X_height, X_width))
        for i in np.arange(H + 1, X_height - H):
            for j in np.arange(W + 1, X_width - W):
                sum = 0
                for k in np.arange(-H, H + 1):
                    for l in np.arange(-W, W + 1):
                        a = X[i + k, j + l]
                        w = F[H + k, W + l]
                        sum += (w * a)
                out[i, j] = sum
        return out

    def konvolusi2D(self):
        img = self.Image
        img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        kernel = np.array(
            [[1, 3, 1],
             [2, 1, 2],
             [1, 2, 3]])
        hasil = self.filtering(img, kernel)
        plt.imshow(hasil, cmap='gray', interpolation='bicubic')
        plt.show()
        cv2.waitKey()
        print(self.Image)


    def displayImage(self, window=1):
        qformat = QImage.Format_Indexed8

        if len(self.Image.shape) == 3:
            if (self.Image.shape[2]) == 4:
                qformat = QImage.Format_RGBA8888
            else:
                qformat = QImage.Format_RGB888

        img = QImage(self.Image, self.Image.shape[1], self.Image.shape[0],
                     self.Image.strides[0], qformat)

        img = img.rgbSwapped()

        if (window == 1):
            self.label.setPixmap(QPixmap.fromImage(img))
            self.label.setScaledContents(True)
        elif (window == 2):
            self.label_2.setPixmap(QPixmap.fromImage(img))
            self.label_2.setScaledContents(True)



app = QtWidgets.QApplication(sys.argv)
window = ShowImage()
# window = setWindowTitle('pertemuan 1')
window.show()
sys.exit(app.exec_())
